-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2024 at 09:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `recipeportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `AdminUserName` varchar(255) DEFAULT NULL,
  `AdminPassword` varchar(255) DEFAULT NULL,
  `AdminEmailId` varchar(255) DEFAULT NULL,
  `userType` int(11) DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `AdminUserName`, `AdminPassword`, `AdminEmailId`, `userType`, `CreationDate`, `UpdationDate`) VALUES
(1, 'admin', 'AdminPassword', 'admin@demo.com', 1, '2022-12-12 18:30:00', '2024-10-12 19:00:22'),
(3, 'sasni_sara', '21232f297a57a5a743894a0e4a801fc3', 'sasni@gmail.com', 0, '2024-10-12 19:00:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(200) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `Is_Active` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Description`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(1, 'Cuisine', 'Cuisine', '2024-10-12 18:43:07', NULL, 1),
(2, 'Breakfast', 'Breakfast', '2024-10-12 18:43:22', NULL, 1),
(3, 'Lunch', 'Lunch', '2024-10-12 18:43:28', NULL, 1),
(4, 'Dinner', 'Dinner', '2024-10-12 18:43:33', NULL, 1),
(5, 'Snacks', 'Snacks', '2024-10-12 18:43:37', NULL, 1),
(6, 'Brunch', 'Brunch', '2024-10-12 18:43:44', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcomments`
--

CREATE TABLE `tblcomments` (
  `id` int(11) NOT NULL,
  `postId` int(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `comment` mediumtext DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext DEFAULT NULL,
  `Description` longtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `PageTitle`, `Description`, `PostingDate`, `UpdationDate`) VALUES
(1, 'aboutus', 'About recipe Portal', 'Demo About Details', '2021-06-29 18:30:00', '2024-10-12 19:09:29'),
(2, 'contactus', 'Contact Details', '<p><br></p><p><b>Address :&nbsp; </b>Maharashtra</p><p><b>Phone Number : </b>+91 -9090909090</p><p><b>Email -id : </b>demo@gmail.com</p>', '2021-06-29 18:30:00', '2024-10-12 19:09:42');

-- --------------------------------------------------------

--
-- Table structure for table `tblposts`
--

CREATE TABLE `tblposts` (
  `id` int(11) NOT NULL,
  `PostTitle` longtext DEFAULT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `SubCategoryId` int(11) DEFAULT NULL,
  `PostDetails` longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `Is_Active` int(1) DEFAULT NULL,
  `PostUrl` mediumtext DEFAULT NULL,
  `PostImage` varchar(255) DEFAULT NULL,
  `viewCounter` int(11) DEFAULT NULL,
  `postedBy` varchar(255) DEFAULT NULL,
  `lastUpdatedBy` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblposts`
--

INSERT INTO `tblposts` (`id`, `PostTitle`, `CategoryId`, `SubCategoryId`, `PostDetails`, `PostingDate`, `UpdationDate`, `Is_Active`, `PostUrl`, `PostImage`, `viewCounter`, `postedBy`, `lastUpdatedBy`) VALUES
(1, 'Chicken Biryani', 3, 3, '<h3>Ingredients:</h3><h4>For Marinating Chicken:</h4><ul><li>500g chicken (cut into medium pieces)</li><li>1 cup plain yogurt</li><li>1 tablespoon ginger-garlic paste</li><li>2 teaspoons biryani masala</li><li>1 teaspoon turmeric powder</li><li>1 teaspoon red chili powder</li><li>½ teaspoon garam masala</li><li>Salt to taste</li><li>2 tablespoons lemon juice</li><li>2 tablespoons oil</li></ul><h4>For Rice:</h4><ul><li>2 cups basmati rice</li><li>4-5 cups water</li><li>1 bay leaf</li><li>2 green cardamom pods</li><li>1 cinnamon stick</li><li>2 cloves</li><li>Salt to taste</li></ul><h4>For Biryani Layer:</h4><ul><li>2 large onions (thinly sliced)</li><li>2 tomatoes (chopped)</li><li>1-2 green chilies (slit)</li><li>2 tablespoons ghee (clarified butter)</li><li>½ cup fresh coriander leaves (chopped)</li><li>½ cup fresh mint leaves (chopped)</li><li>A pinch of saffron soaked in 2 tablespoons warm milk (optional)</li><li>2-3 tablespoons fried onions for garnish</li><li>1 teaspoon garam masala</li></ul><h3>Instructions:</h3><h4>Step 1: Marinate the Chicken</h4><ol><li>In a large bowl, mix the yogurt, ginger-garlic paste, biryani masala, turmeric powder, red chili powder, garam masala, lemon juice, oil, and salt.</li><li>Add the chicken pieces to the marinade and mix well. Cover and refrigerate for at least 1 hour, or preferably overnight for better flavor.</li></ol><h4>Step 2: Cook the Rice</h4><ol><li>Rinse the basmati rice under cold water until the water runs clear. Soak the rice in water for 20 minutes, then drain.</li><li>In a large pot, bring 4-5 cups of water to a boil. Add the bay leaf, cardamom pods, cinnamon stick, cloves, and salt.</li><li>Add the soaked rice and cook until 70-80% done (the rice should be slightly firm). Drain and set aside.</li></ol><h4>Step 3: Prepare the Chicken Biryani Masala</h4><ol><li>Heat 2 tablespoons of ghee in a large pan or pot. Add the sliced onions and sauté until they are golden brown and crispy. Remove half of the onions and set aside for garnish.</li><li>Add the green chilies to the remaining onions in the pan and sauté for a minute.</li><li>Add the marinated chicken and cook on medium heat until the chicken is browned and partially cooked, about 10 minutes.</li><li>Add the chopped tomatoes and cook until they soften, about 5 minutes.</li><li>Add chopped coriander and mint leaves, and stir everything together. Remove from heat.</li></ol><h4>Step 4: Assemble the Biryani</h4><ol><li>In a heavy-bottomed pan or large pot, layer half of the cooked chicken mixture at the bottom.</li><li>Add half of the partially cooked rice on top of the chicken layer.</li><li>Sprinkle half of the reserved fried onions, half of the garam masala, and half of the saffron milk over the rice.</li><li>Repeat the layers with the remaining chicken, rice, fried onions, garam masala, and saffron milk.</li><li>Cover the pot with a tight-fitting lid or aluminum foil to seal in the steam.</li></ol><h4>Step 5: Dum Cooking (Steaming)</h4><ol><li>Place the pot on low heat and let it cook for 20-25 minutes. You can place the pot on a heated tawa (griddle) to prevent direct heat from burning the bottom layer.</li><li>Once done, let the biryani rest for 10 minutes before serving.</li></ol><h4>Step 6: Serve</h4><ul><li>Gently fluff the rice with a fork, being careful not to break the grains.</li><li>Serve hot, garnished with fried onions, fresh coriander leaves, and a side of raita or salad.</li></ul><p>Enjoy your delicious homemade <strong>Chicken Biryani</strong>!</p>', '2024-10-12 18:45:18', NULL, 1, 'Chicken-Biryani', '0bfb16d9709c2707ece2bc98dc829f92.jpg', NULL, 'admin', NULL),
(2, 'Chicken Biryani', 3, 3, '<h3>Ingredients:</h3><h4>For Marinating Chicken:</h4><ul><li>500g chicken (cut into medium pieces)</li><li>1 cup plain yogurt</li><li>1 tablespoon ginger-garlic paste</li><li>2 teaspoons biryani masala</li><li>1 teaspoon turmeric powder</li><li>1 teaspoon red chili powder</li><li>½ teaspoon garam masala</li><li>Salt to taste</li><li>2 tablespoons lemon juice</li><li>2 tablespoons oil</li></ul><h4>For Rice:</h4><ul><li>2 cups basmati rice</li><li>4-5 cups water</li><li>1 bay leaf</li><li>2 green cardamom pods</li><li>1 cinnamon stick</li><li>2 cloves</li><li>Salt to taste</li></ul><h4>For Biryani Layer:</h4><ul><li>2 large onions (thinly sliced)</li><li>2 tomatoes (chopped)</li><li>1-2 green chilies (slit)</li><li>2 tablespoons ghee (clarified butter)</li><li>½ cup fresh coriander leaves (chopped)</li><li>½ cup fresh mint leaves (chopped)</li><li>A pinch of saffron soaked in 2 tablespoons warm milk (optional)</li><li>2-3 tablespoons fried onions for garnish</li><li>1 teaspoon garam masala</li></ul><h3>Instructions:</h3><h4>Step 1: Marinate the Chicken</h4><ol><li>In a large bowl, mix the yogurt, ginger-garlic paste, biryani masala, turmeric powder, red chili powder, garam masala, lemon juice, oil, and salt.</li><li>Add the chicken pieces to the marinade and mix well. Cover and refrigerate for at least 1 hour, or preferably overnight for better flavor.</li></ol><h4>Step 2: Cook the Rice</h4><ol><li>Rinse the basmati rice under cold water until the water runs clear. Soak the rice in water for 20 minutes, then drain.</li><li>In a large pot, bring 4-5 cups of water to a boil. Add the bay leaf, cardamom pods, cinnamon stick, cloves, and salt.</li><li>Add the soaked rice and cook until 70-80% done (the rice should be slightly firm). Drain and set aside.</li></ol><h4>Step 3: Prepare the Chicken Biryani Masala</h4><ol><li>Heat 2 tablespoons of ghee in a large pan or pot. Add the sliced onions and sauté until they are golden brown and crispy. Remove half of the onions and set aside for garnish.</li><li>Add the green chilies to the remaining onions in the pan and sauté for a minute.</li><li>Add the marinated chicken and cook on medium heat until the chicken is browned and partially cooked, about 10 minutes.</li><li>Add the chopped tomatoes and cook until they soften, about 5 minutes.</li><li>Add chopped coriander and mint leaves, and stir everything together. Remove from heat.</li></ol><h4>Step 4: Assemble the Biryani</h4><ol><li>In a heavy-bottomed pan or large pot, layer half of the cooked chicken mixture at the bottom.</li><li>Add half of the partially cooked rice on top of the chicken layer.</li><li>Sprinkle half of the reserved fried onions, half of the garam masala, and half of the saffron milk over the rice.</li><li>Repeat the layers with the remaining chicken, rice, fried onions, garam masala, and saffron milk.</li><li>Cover the pot with a tight-fitting lid or aluminum foil to seal in the steam.</li></ol><h4>Step 5: Dum Cooking (Steaming)</h4><ol><li>Place the pot on low heat and let it cook for 20-25 minutes. You can place the pot on a heated tawa (griddle) to prevent direct heat from burning the bottom layer.</li><li>Once done, let the biryani rest for 10 minutes before serving.</li></ol><h4>Step 6: Serve</h4><ul><li>Gently fluff the rice with a fork, being careful not to break the grains.</li><li>Serve hot, garnished with fried onions, fresh coriander leaves, and a side of raita or salad.</li></ul><p>Enjoy your delicious homemade <strong>Chicken Biryani</strong>!</p>', '2024-10-12 18:45:18', NULL, 1, 'Chicken-Biryani', '0bfb16d9709c2707ece2bc98dc829f92.jpg', NULL, 'admin', NULL),
(3, 'Chicken Biryani', 3, 3, '<h3>Ingredients:</h3><h4>For Marinating Chicken:</h4><ul><li>500g chicken (cut into medium pieces)</li><li>1 cup plain yogurt</li><li>1 tablespoon ginger-garlic paste</li><li>2 teaspoons biryani masala</li><li>1 teaspoon turmeric powder</li><li>1 teaspoon red chili powder</li><li>½ teaspoon garam masala</li><li>Salt to taste</li><li>2 tablespoons lemon juice</li><li>2 tablespoons oil</li></ul><h4>For Rice:</h4><ul><li>2 cups basmati rice</li><li>4-5 cups water</li><li>1 bay leaf</li><li>2 green cardamom pods</li><li>1 cinnamon stick</li><li>2 cloves</li><li>Salt to taste</li></ul><h4>For Biryani Layer:</h4><ul><li>2 large onions (thinly sliced)</li><li>2 tomatoes (chopped)</li><li>1-2 green chilies (slit)</li><li>2 tablespoons ghee (clarified butter)</li><li>½ cup fresh coriander leaves (chopped)</li><li>½ cup fresh mint leaves (chopped)</li><li>A pinch of saffron soaked in 2 tablespoons warm milk (optional)</li><li>2-3 tablespoons fried onions for garnish</li><li>1 teaspoon garam masala</li></ul><h3>Instructions:</h3><h4>Step 1: Marinate the Chicken</h4><ol><li>In a large bowl, mix the yogurt, ginger-garlic paste, biryani masala, turmeric powder, red chili powder, garam masala, lemon juice, oil, and salt.</li><li>Add the chicken pieces to the marinade and mix well. Cover and refrigerate for at least 1 hour, or preferably overnight for better flavor.</li></ol><h4>Step 2: Cook the Rice</h4><ol><li>Rinse the basmati rice under cold water until the water runs clear. Soak the rice in water for 20 minutes, then drain.</li><li>In a large pot, bring 4-5 cups of water to a boil. Add the bay leaf, cardamom pods, cinnamon stick, cloves, and salt.</li><li>Add the soaked rice and cook until 70-80% done (the rice should be slightly firm). Drain and set aside.</li></ol><h4>Step 3: Prepare the Chicken Biryani Masala</h4><ol><li>Heat 2 tablespoons of ghee in a large pan or pot. Add the sliced onions and sauté until they are golden brown and crispy. Remove half of the onions and set aside for garnish.</li><li>Add the green chilies to the remaining onions in the pan and sauté for a minute.</li><li>Add the marinated chicken and cook on medium heat until the chicken is browned and partially cooked, about 10 minutes.</li><li>Add the chopped tomatoes and cook until they soften, about 5 minutes.</li><li>Add chopped coriander and mint leaves, and stir everything together. Remove from heat.</li></ol><h4>Step 4: Assemble the Biryani</h4><ol><li>In a heavy-bottomed pan or large pot, layer half of the cooked chicken mixture at the bottom.</li><li>Add half of the partially cooked rice on top of the chicken layer.</li><li>Sprinkle half of the reserved fried onions, half of the garam masala, and half of the saffron milk over the rice.</li><li>Repeat the layers with the remaining chicken, rice, fried onions, garam masala, and saffron milk.</li><li>Cover the pot with a tight-fitting lid or aluminum foil to seal in the steam.</li></ol><h4>Step 5: Dum Cooking (Steaming)</h4><ol><li>Place the pot on low heat and let it cook for 20-25 minutes. You can place the pot on a heated tawa (griddle) to prevent direct heat from burning the bottom layer.</li><li>Once done, let the biryani rest for 10 minutes before serving.</li></ol><h4>Step 6: Serve</h4><ul><li>Gently fluff the rice with a fork, being careful not to break the grains.</li><li>Serve hot, garnished with fried onions, fresh coriander leaves, and a side of raita or salad.</li></ul><p>Enjoy your delicious homemade <strong>Chicken Biryani</strong>!</p>', '2024-10-12 18:45:18', NULL, 1, 'Chicken-Biryani', '0bfb16d9709c2707ece2bc98dc829f92.jpg', NULL, 'admin', NULL),
(4, 'Chicken Biryani', 3, 3, '<h3>Ingredients:</h3><h4>For Marinating Chicken:</h4><ul><li>500g chicken (cut into medium pieces)</li><li>1 cup plain yogurt</li><li>1 tablespoon ginger-garlic paste</li><li>2 teaspoons biryani masala</li><li>1 teaspoon turmeric powder</li><li>1 teaspoon red chili powder</li><li>½ teaspoon garam masala</li><li>Salt to taste</li><li>2 tablespoons lemon juice</li><li>2 tablespoons oil</li></ul><h4>For Rice:</h4><ul><li>2 cups basmati rice</li><li>4-5 cups water</li><li>1 bay leaf</li><li>2 green cardamom pods</li><li>1 cinnamon stick</li><li>2 cloves</li><li>Salt to taste</li></ul><h4>For Biryani Layer:</h4><ul><li>2 large onions (thinly sliced)</li><li>2 tomatoes (chopped)</li><li>1-2 green chilies (slit)</li><li>2 tablespoons ghee (clarified butter)</li><li>½ cup fresh coriander leaves (chopped)</li><li>½ cup fresh mint leaves (chopped)</li><li>A pinch of saffron soaked in 2 tablespoons warm milk (optional)</li><li>2-3 tablespoons fried onions for garnish</li><li>1 teaspoon garam masala</li></ul><h3>Instructions:</h3><h4>Step 1: Marinate the Chicken</h4><ol><li>In a large bowl, mix the yogurt, ginger-garlic paste, biryani masala, turmeric powder, red chili powder, garam masala, lemon juice, oil, and salt.</li><li>Add the chicken pieces to the marinade and mix well. Cover and refrigerate for at least 1 hour, or preferably overnight for better flavor.</li></ol><h4>Step 2: Cook the Rice</h4><ol><li>Rinse the basmati rice under cold water until the water runs clear. Soak the rice in water for 20 minutes, then drain.</li><li>In a large pot, bring 4-5 cups of water to a boil. Add the bay leaf, cardamom pods, cinnamon stick, cloves, and salt.</li><li>Add the soaked rice and cook until 70-80% done (the rice should be slightly firm). Drain and set aside.</li></ol><h4>Step 3: Prepare the Chicken Biryani Masala</h4><ol><li>Heat 2 tablespoons of ghee in a large pan or pot. Add the sliced onions and sauté until they are golden brown and crispy. Remove half of the onions and set aside for garnish.</li><li>Add the green chilies to the remaining onions in the pan and sauté for a minute.</li><li>Add the marinated chicken and cook on medium heat until the chicken is browned and partially cooked, about 10 minutes.</li><li>Add the chopped tomatoes and cook until they soften, about 5 minutes.</li><li>Add chopped coriander and mint leaves, and stir everything together. Remove from heat.</li></ol><h4>Step 4: Assemble the Biryani</h4><ol><li>In a heavy-bottomed pan or large pot, layer half of the cooked chicken mixture at the bottom.</li><li>Add half of the partially cooked rice on top of the chicken layer.</li><li>Sprinkle half of the reserved fried onions, half of the garam masala, and half of the saffron milk over the rice.</li><li>Repeat the layers with the remaining chicken, rice, fried onions, garam masala, and saffron milk.</li><li>Cover the pot with a tight-fitting lid or aluminum foil to seal in the steam.</li></ol><h4>Step 5: Dum Cooking (Steaming)</h4><ol><li>Place the pot on low heat and let it cook for 20-25 minutes. You can place the pot on a heated tawa (griddle) to prevent direct heat from burning the bottom layer.</li><li>Once done, let the biryani rest for 10 minutes before serving.</li></ol><h4>Step 6: Serve</h4><ul><li>Gently fluff the rice with a fork, being careful not to break the grains.</li><li>Serve hot, garnished with fried onions, fresh coriander leaves, and a side of raita or salad.</li></ul><p>Enjoy your delicious homemade <strong>Chicken Biryani</strong>!</p>', '2024-10-12 18:45:18', NULL, 1, 'Chicken-Biryani', '0bfb16d9709c2707ece2bc98dc829f92.jpg', NULL, 'admin', NULL),
(5, 'Chicken Biryani', 3, 3, '<h3>Ingredients:</h3><h4>For Marinating Chicken:</h4><ul><li>500g chicken (cut into medium pieces)</li><li>1 cup plain yogurt</li><li>1 tablespoon ginger-garlic paste</li><li>2 teaspoons biryani masala</li><li>1 teaspoon turmeric powder</li><li>1 teaspoon red chili powder</li><li>½ teaspoon garam masala</li><li>Salt to taste</li><li>2 tablespoons lemon juice</li><li>2 tablespoons oil</li></ul><h4>For Rice:</h4><ul><li>2 cups basmati rice</li><li>4-5 cups water</li><li>1 bay leaf</li><li>2 green cardamom pods</li><li>1 cinnamon stick</li><li>2 cloves</li><li>Salt to taste</li></ul><h4>For Biryani Layer:</h4><ul><li>2 large onions (thinly sliced)</li><li>2 tomatoes (chopped)</li><li>1-2 green chilies (slit)</li><li>2 tablespoons ghee (clarified butter)</li><li>½ cup fresh coriander leaves (chopped)</li><li>½ cup fresh mint leaves (chopped)</li><li>A pinch of saffron soaked in 2 tablespoons warm milk (optional)</li><li>2-3 tablespoons fried onions for garnish</li><li>1 teaspoon garam masala</li></ul><h3>Instructions:</h3><h4>Step 1: Marinate the Chicken</h4><ol><li>In a large bowl, mix the yogurt, ginger-garlic paste, biryani masala, turmeric powder, red chili powder, garam masala, lemon juice, oil, and salt.</li><li>Add the chicken pieces to the marinade and mix well. Cover and refrigerate for at least 1 hour, or preferably overnight for better flavor.</li></ol><h4>Step 2: Cook the Rice</h4><ol><li>Rinse the basmati rice under cold water until the water runs clear. Soak the rice in water for 20 minutes, then drain.</li><li>In a large pot, bring 4-5 cups of water to a boil. Add the bay leaf, cardamom pods, cinnamon stick, cloves, and salt.</li><li>Add the soaked rice and cook until 70-80% done (the rice should be slightly firm). Drain and set aside.</li></ol><h4>Step 3: Prepare the Chicken Biryani Masala</h4><ol><li>Heat 2 tablespoons of ghee in a large pan or pot. Add the sliced onions and sauté until they are golden brown and crispy. Remove half of the onions and set aside for garnish.</li><li>Add the green chilies to the remaining onions in the pan and sauté for a minute.</li><li>Add the marinated chicken and cook on medium heat until the chicken is browned and partially cooked, about 10 minutes.</li><li>Add the chopped tomatoes and cook until they soften, about 5 minutes.</li><li>Add chopped coriander and mint leaves, and stir everything together. Remove from heat.</li></ol><h4>Step 4: Assemble the Biryani</h4><ol><li>In a heavy-bottomed pan or large pot, layer half of the cooked chicken mixture at the bottom.</li><li>Add half of the partially cooked rice on top of the chicken layer.</li><li>Sprinkle half of the reserved fried onions, half of the garam masala, and half of the saffron milk over the rice.</li><li>Repeat the layers with the remaining chicken, rice, fried onions, garam masala, and saffron milk.</li><li>Cover the pot with a tight-fitting lid or aluminum foil to seal in the steam.</li></ol><h4>Step 5: Dum Cooking (Steaming)</h4><ol><li>Place the pot on low heat and let it cook for 20-25 minutes. You can place the pot on a heated tawa (griddle) to prevent direct heat from burning the bottom layer.</li><li>Once done, let the biryani rest for 10 minutes before serving.</li></ol><h4>Step 6: Serve</h4><ul><li>Gently fluff the rice with a fork, being careful not to break the grains.</li><li>Serve hot, garnished with fried onions, fresh coriander leaves, and a side of raita or salad.</li></ul><p>Enjoy your delicious homemade <strong>Chicken Biryani</strong>!</p>', '2024-10-12 18:45:18', NULL, 1, 'Chicken-Biryani', '0bfb16d9709c2707ece2bc98dc829f92.jpg', NULL, 'admin', NULL),
(6, 'Chicken Biryani', 3, 3, '<h3>Ingredients:</h3><h4>For Marinating Chicken:</h4><ul><li>500g chicken (cut into medium pieces)</li><li>1 cup plain yogurt</li><li>1 tablespoon ginger-garlic paste</li><li>2 teaspoons biryani masala</li><li>1 teaspoon turmeric powder</li><li>1 teaspoon red chili powder</li><li>½ teaspoon garam masala</li><li>Salt to taste</li><li>2 tablespoons lemon juice</li><li>2 tablespoons oil</li></ul><h4>For Rice:</h4><ul><li>2 cups basmati rice</li><li>4-5 cups water</li><li>1 bay leaf</li><li>2 green cardamom pods</li><li>1 cinnamon stick</li><li>2 cloves</li><li>Salt to taste</li></ul><h4>For Biryani Layer:</h4><ul><li>2 large onions (thinly sliced)</li><li>2 tomatoes (chopped)</li><li>1-2 green chilies (slit)</li><li>2 tablespoons ghee (clarified butter)</li><li>½ cup fresh coriander leaves (chopped)</li><li>½ cup fresh mint leaves (chopped)</li><li>A pinch of saffron soaked in 2 tablespoons warm milk (optional)</li><li>2-3 tablespoons fried onions for garnish</li><li>1 teaspoon garam masala</li></ul><h3>Instructions:</h3><h4>Step 1: Marinate the Chicken</h4><ol><li>In a large bowl, mix the yogurt, ginger-garlic paste, biryani masala, turmeric powder, red chili powder, garam masala, lemon juice, oil, and salt.</li><li>Add the chicken pieces to the marinade and mix well. Cover and refrigerate for at least 1 hour, or preferably overnight for better flavor.</li></ol><h4>Step 2: Cook the Rice</h4><ol><li>Rinse the basmati rice under cold water until the water runs clear. Soak the rice in water for 20 minutes, then drain.</li><li>In a large pot, bring 4-5 cups of water to a boil. Add the bay leaf, cardamom pods, cinnamon stick, cloves, and salt.</li><li>Add the soaked rice and cook until 70-80% done (the rice should be slightly firm). Drain and set aside.</li></ol><h4>Step 3: Prepare the Chicken Biryani Masala</h4><ol><li>Heat 2 tablespoons of ghee in a large pan or pot. Add the sliced onions and sauté until they are golden brown and crispy. Remove half of the onions and set aside for garnish.</li><li>Add the green chilies to the remaining onions in the pan and sauté for a minute.</li><li>Add the marinated chicken and cook on medium heat until the chicken is browned and partially cooked, about 10 minutes.</li><li>Add the chopped tomatoes and cook until they soften, about 5 minutes.</li><li>Add chopped coriander and mint leaves, and stir everything together. Remove from heat.</li></ol><h4>Step 4: Assemble the Biryani</h4><ol><li>In a heavy-bottomed pan or large pot, layer half of the cooked chicken mixture at the bottom.</li><li>Add half of the partially cooked rice on top of the chicken layer.</li><li>Sprinkle half of the reserved fried onions, half of the garam masala, and half of the saffron milk over the rice.</li><li>Repeat the layers with the remaining chicken, rice, fried onions, garam masala, and saffron milk.</li><li>Cover the pot with a tight-fitting lid or aluminum foil to seal in the steam.</li></ol><h4>Step 5: Dum Cooking (Steaming)</h4><ol><li>Place the pot on low heat and let it cook for 20-25 minutes. You can place the pot on a heated tawa (griddle) to prevent direct heat from burning the bottom layer.</li><li>Once done, let the biryani rest for 10 minutes before serving.</li></ol><h4>Step 6: Serve</h4><ul><li>Gently fluff the rice with a fork, being careful not to break the grains.</li><li>Serve hot, garnished with fried onions, fresh coriander leaves, and a side of raita or salad.</li></ul><p>Enjoy your delicious homemade <strong>Chicken Biryani</strong>!</p>', '2024-10-12 18:45:18', NULL, 1, 'Chicken-Biryani', '0bfb16d9709c2707ece2bc98dc829f92.jpg', NULL, 'admin', NULL),
(7, 'Chicken Biryani', 3, 3, '<h3>Ingredients:</h3><h4>For Marinating Chicken:</h4><ul><li>500g chicken (cut into medium pieces)</li><li>1 cup plain yogurt</li><li>1 tablespoon ginger-garlic paste</li><li>2 teaspoons biryani masala</li><li>1 teaspoon turmeric powder</li><li>1 teaspoon red chili powder</li><li>½ teaspoon garam masala</li><li>Salt to taste</li><li>2 tablespoons lemon juice</li><li>2 tablespoons oil</li></ul><h4>For Rice:</h4><ul><li>2 cups basmati rice</li><li>4-5 cups water</li><li>1 bay leaf</li><li>2 green cardamom pods</li><li>1 cinnamon stick</li><li>2 cloves</li><li>Salt to taste</li></ul><h4>For Biryani Layer:</h4><ul><li>2 large onions (thinly sliced)</li><li>2 tomatoes (chopped)</li><li>1-2 green chilies (slit)</li><li>2 tablespoons ghee (clarified butter)</li><li>½ cup fresh coriander leaves (chopped)</li><li>½ cup fresh mint leaves (chopped)</li><li>A pinch of saffron soaked in 2 tablespoons warm milk (optional)</li><li>2-3 tablespoons fried onions for garnish</li><li>1 teaspoon garam masala</li></ul><h3>Instructions:</h3><h4>Step 1: Marinate the Chicken</h4><ol><li>In a large bowl, mix the yogurt, ginger-garlic paste, biryani masala, turmeric powder, red chili powder, garam masala, lemon juice, oil, and salt.</li><li>Add the chicken pieces to the marinade and mix well. Cover and refrigerate for at least 1 hour, or preferably overnight for better flavor.</li></ol><h4>Step 2: Cook the Rice</h4><ol><li>Rinse the basmati rice under cold water until the water runs clear. Soak the rice in water for 20 minutes, then drain.</li><li>In a large pot, bring 4-5 cups of water to a boil. Add the bay leaf, cardamom pods, cinnamon stick, cloves, and salt.</li><li>Add the soaked rice and cook until 70-80% done (the rice should be slightly firm). Drain and set aside.</li></ol><h4>Step 3: Prepare the Chicken Biryani Masala</h4><ol><li>Heat 2 tablespoons of ghee in a large pan or pot. Add the sliced onions and sauté until they are golden brown and crispy. Remove half of the onions and set aside for garnish.</li><li>Add the green chilies to the remaining onions in the pan and sauté for a minute.</li><li>Add the marinated chicken and cook on medium heat until the chicken is browned and partially cooked, about 10 minutes.</li><li>Add the chopped tomatoes and cook until they soften, about 5 minutes.</li><li>Add chopped coriander and mint leaves, and stir everything together. Remove from heat.</li></ol><h4>Step 4: Assemble the Biryani</h4><ol><li>In a heavy-bottomed pan or large pot, layer half of the cooked chicken mixture at the bottom.</li><li>Add half of the partially cooked rice on top of the chicken layer.</li><li>Sprinkle half of the reserved fried onions, half of the garam masala, and half of the saffron milk over the rice.</li><li>Repeat the layers with the remaining chicken, rice, fried onions, garam masala, and saffron milk.</li><li>Cover the pot with a tight-fitting lid or aluminum foil to seal in the steam.</li></ol><h4>Step 5: Dum Cooking (Steaming)</h4><ol><li>Place the pot on low heat and let it cook for 20-25 minutes. You can place the pot on a heated tawa (griddle) to prevent direct heat from burning the bottom layer.</li><li>Once done, let the biryani rest for 10 minutes before serving.</li></ol><h4>Step 6: Serve</h4><ul><li>Gently fluff the rice with a fork, being careful not to break the grains.</li><li>Serve hot, garnished with fried onions, fresh coriander leaves, and a side of raita or salad.</li></ul><p>Enjoy your delicious homemade <strong>Chicken Biryani</strong>!</p>', '2024-10-12 18:45:18', NULL, 1, 'Chicken-Biryani', '0bfb16d9709c2707ece2bc98dc829f92.jpg', NULL, 'admin', NULL),
(8, 'Chicken Biryani', 3, 3, '<h3>Ingredients:</h3><h4>For Marinating Chicken:</h4><ul><li>500g chicken (cut into medium pieces)</li><li>1 cup plain yogurt</li><li>1 tablespoon ginger-garlic paste</li><li>2 teaspoons biryani masala</li><li>1 teaspoon turmeric powder</li><li>1 teaspoon red chili powder</li><li>½ teaspoon garam masala</li><li>Salt to taste</li><li>2 tablespoons lemon juice</li><li>2 tablespoons oil</li></ul><h4>For Rice:</h4><ul><li>2 cups basmati rice</li><li>4-5 cups water</li><li>1 bay leaf</li><li>2 green cardamom pods</li><li>1 cinnamon stick</li><li>2 cloves</li><li>Salt to taste</li></ul><h4>For Biryani Layer:</h4><ul><li>2 large onions (thinly sliced)</li><li>2 tomatoes (chopped)</li><li>1-2 green chilies (slit)</li><li>2 tablespoons ghee (clarified butter)</li><li>½ cup fresh coriander leaves (chopped)</li><li>½ cup fresh mint leaves (chopped)</li><li>A pinch of saffron soaked in 2 tablespoons warm milk (optional)</li><li>2-3 tablespoons fried onions for garnish</li><li>1 teaspoon garam masala</li></ul><h3>Instructions:</h3><h4>Step 1: Marinate the Chicken</h4><ol><li>In a large bowl, mix the yogurt, ginger-garlic paste, biryani masala, turmeric powder, red chili powder, garam masala, lemon juice, oil, and salt.</li><li>Add the chicken pieces to the marinade and mix well. Cover and refrigerate for at least 1 hour, or preferably overnight for better flavor.</li></ol><h4>Step 2: Cook the Rice</h4><ol><li>Rinse the basmati rice under cold water until the water runs clear. Soak the rice in water for 20 minutes, then drain.</li><li>In a large pot, bring 4-5 cups of water to a boil. Add the bay leaf, cardamom pods, cinnamon stick, cloves, and salt.</li><li>Add the soaked rice and cook until 70-80% done (the rice should be slightly firm). Drain and set aside.</li></ol><h4>Step 3: Prepare the Chicken Biryani Masala</h4><ol><li>Heat 2 tablespoons of ghee in a large pan or pot. Add the sliced onions and sauté until they are golden brown and crispy. Remove half of the onions and set aside for garnish.</li><li>Add the green chilies to the remaining onions in the pan and sauté for a minute.</li><li>Add the marinated chicken and cook on medium heat until the chicken is browned and partially cooked, about 10 minutes.</li><li>Add the chopped tomatoes and cook until they soften, about 5 minutes.</li><li>Add chopped coriander and mint leaves, and stir everything together. Remove from heat.</li></ol><h4>Step 4: Assemble the Biryani</h4><ol><li>In a heavy-bottomed pan or large pot, layer half of the cooked chicken mixture at the bottom.</li><li>Add half of the partially cooked rice on top of the chicken layer.</li><li>Sprinkle half of the reserved fried onions, half of the garam masala, and half of the saffron milk over the rice.</li><li>Repeat the layers with the remaining chicken, rice, fried onions, garam masala, and saffron milk.</li><li>Cover the pot with a tight-fitting lid or aluminum foil to seal in the steam.</li></ol><h4>Step 5: Dum Cooking (Steaming)</h4><ol><li>Place the pot on low heat and let it cook for 20-25 minutes. You can place the pot on a heated tawa (griddle) to prevent direct heat from burning the bottom layer.</li><li>Once done, let the biryani rest for 10 minutes before serving.</li></ol><h4>Step 6: Serve</h4><ul><li>Gently fluff the rice with a fork, being careful not to break the grains.</li><li>Serve hot, garnished with fried onions, fresh coriander leaves, and a side of raita or salad.</li></ul><p>Enjoy your delicious homemade <strong>Chicken Biryani</strong>!</p>', '2024-10-12 18:45:18', NULL, 1, 'Chicken-Biryani', '0bfb16d9709c2707ece2bc98dc829f92.jpg', NULL, 'admin', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubcategory`
--

CREATE TABLE `tblsubcategory` (
  `SubCategoryId` int(11) NOT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `Subcategory` varchar(255) DEFAULT NULL,
  `SubCatDescription` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `Is_Active` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblsubcategory`
--

INSERT INTO `tblsubcategory` (`SubCategoryId`, `CategoryId`, `Subcategory`, `SubCatDescription`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(1, 1, 'Demo Sub', 'Demo Sub', '2024-10-12 18:43:55', NULL, 1),
(2, 2, 'Demo Sub', 'Demo Sub', '2024-10-12 18:44:01', NULL, 1),
(3, 3, 'Demo Sub', 'Demo Sub', '2024-10-12 18:44:05', NULL, 1),
(4, 4, 'Demo Sub', 'Demo Sub', '2024-10-12 18:44:09', NULL, 1),
(5, 5, 'Demo Sub', 'Demo Sub', '2024-10-12 18:44:13', NULL, 1),
(6, 6, 'Demo Sub', 'Demo Sub', '2024-10-12 18:44:18', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `AdminUserName` (`AdminUserName`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomments`
--
ALTER TABLE `tblcomments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `postId` (`postId`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblposts`
--
ALTER TABLE `tblposts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `postcatid` (`CategoryId`),
  ADD KEY `postsucatid` (`SubCategoryId`),
  ADD KEY `subadmin` (`postedBy`);

--
-- Indexes for table `tblsubcategory`
--
ALTER TABLE `tblsubcategory`
  ADD PRIMARY KEY (`SubCategoryId`),
  ADD KEY `catid` (`CategoryId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblcomments`
--
ALTER TABLE `tblcomments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblposts`
--
ALTER TABLE `tblposts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblsubcategory`
--
ALTER TABLE `tblsubcategory`
  MODIFY `SubCategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblcomments`
--
ALTER TABLE `tblcomments`
  ADD CONSTRAINT `pid` FOREIGN KEY (`postId`) REFERENCES `tblposts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblposts`
--
ALTER TABLE `tblposts`
  ADD CONSTRAINT `postcatid` FOREIGN KEY (`CategoryId`) REFERENCES `tblcategory` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `postsucatid` FOREIGN KEY (`SubCategoryId`) REFERENCES `tblsubcategory` (`SubCategoryId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `subadmin` FOREIGN KEY (`postedBy`) REFERENCES `tbladmin` (`AdminUserName`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tblsubcategory`
--
ALTER TABLE `tblsubcategory`
  ADD CONSTRAINT `catid` FOREIGN KEY (`CategoryId`) REFERENCES `tblcategory` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
