<footer>
	<div style="text-align:
center; padding:10px;
background-color:skyblue; color: white;">
	<p>&copy; <?php echo
date("Y"); ?>Golden Chikky Resturent. All rights reserved.</p>
	<p>Designed by Sasni Sara</p>
		</div>
</footer>